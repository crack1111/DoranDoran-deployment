document.addEventListener("DOMContentLoaded", function() {
	connectWebSocketAlert();

	const readAlertIcon = document.getElementById("readAlert");
	if (readAlertIcon) {
		readAlertIcon.addEventListener("click", function() {
			fetch('/alert/read', {
				method: 'PUT',
				headers: {
					'Content-Type': 'application/json'
				}
			}).then(response => {
				if (response.ok) {
					console.log("전체 알림 읽음 처리 완료");
					const badge = document.querySelector(".notification-badge");
					if (badge) badge.style.display = "none";
				} else {
					console.error("알림 읽음 처리 실패");
				}
			});
		});
	} else {
		console.warn("#readAlert 요소를 찾을 수 없습니다.");
	}
});

let socket = new SockJS("/ws"); // WebSocket 엔드포인트
let stompClient = Stomp.over(socket);

function connectWebSocketAlert() {
	stompClient.connect({}, function(frame) {
		console.log("✅ STOMP 연결됨: ", frame);

		stompClient.subscribe("/user/queue/alerts", function(message) {
			try {
				const alert = JSON.parse(message.body);
				console.log("알림 수신", alert);
				handleIncomingAlert(alert);
			} catch (e) {
				console.error("⚠️ 메시지 파싱 실패:", e);
			}
		});

		console.log("📡 알림 구독 완료: /user/queue/alerts");
	});
}
