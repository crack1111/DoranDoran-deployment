package kr.ac.kopo.dorandoran;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DoranDoranApplicationTests {

	@Test
	void contextLoads() {
	}
}
